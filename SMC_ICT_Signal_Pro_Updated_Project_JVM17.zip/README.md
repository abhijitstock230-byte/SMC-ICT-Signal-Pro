# SMC ICT Signal Pro — Android starter project

This project builds an installable Android debug APK through GitHub Actions.

## Features
- Android app UI
- Live crypto candles from Binance public REST API
- Enter symbols such as BTCUSDT, ETHUSDT, SOLUSDT
- Timeframes: 15m, 1h, 4h, 1d
- Shows last price, EMA 9/21 trend, recent 20-candle swing high/low, and a basic setup/bias label

## Important limitations
- This is a starter prototype, not a complete or validated SMC/ICT trading system.
- The signal uses an EMA trend filter and recent swing range; it does not fully detect order blocks, fair value gaps, liquidity sweeps, or market structure shifts.
- Live feed is crypto only through Binance. Stock and forex feeds need a suitable provider and usually an API key.
- Signals are educational only, not financial advice. Test on demo/historical data before relying on them.

## Build APK using a phone
1. Create a GitHub repository and upload all files/folders from this project.
2. Open the repository's Actions tab.
3. Select **Build SMC ICT Signal Pro APK**.
4. Tap **Run workflow** if it has not started automatically.
5. Wait for the run to finish successfully.
6. Open the completed workflow run, scroll to Artifacts, and download `SMC-ICT-Signal-Pro-APK`.
7. GitHub downloads the artifact as a ZIP. Extract it; inside is `app-debug.apk`. The installable app file itself ends in `.apk`.
8. Open `app-debug.apk` on your Android phone and allow installation from that source if Android asks.

## Requirements
GitHub Actions can build the project in the cloud, so Android Studio is not required on your phone.
