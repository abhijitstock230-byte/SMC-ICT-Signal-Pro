package com.smcict.signalpro

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.text.DecimalFormat
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var market: Spinner
    private lateinit var timeframe: Spinner
    private lateinit var resultBox: TextView
    private lateinit var status: TextView
    private val df = DecimalFormat("#,##0.########")

    private data class Instrument(val label: String, val symbol: String, val category: String, val provider: String)
    private val instruments = listOf(
        Instrument("NIFTY 50", "NIFTY 50", "INDIA", "Not connected"),
        Instrument("BANKNIFTY", "BANKNIFTY", "INDIA", "Not connected"),
        Instrument("SENSEX", "SENSEX", "INDIA", "Not connected"),
        Instrument("FINNIFTY", "FINNIFTY", "INDIA", "Not connected"),
        Instrument("MIDCPNIFTY", "MIDCPNIFTY", "INDIA", "Not connected"),
        Instrument("BTC/USDT", "BTCUSDT", "CRYPTO", "Binance"),
        Instrument("ETH/USDT", "ETHUSDT", "CRYPTO", "Binance"),
        Instrument("BNB/USDT", "BNBUSDT", "CRYPTO", "Binance"),
        Instrument("SOL/USDT", "SOLUSDT", "CRYPTO", "Binance"),
        Instrument("XRP/USDT", "XRPUSDT", "CRYPTO", "Binance"),
        Instrument("DOGE/USDT", "DOGEUSDT", "CRYPTO", "Binance"),
        Instrument("EUR/USD", "EURUSD", "FOREX", "Not connected"),
        Instrument("GBP/USD", "GBPUSD", "FOREX", "Not connected"),
        Instrument("USD/JPY", "USDJPY", "FOREX", "Not connected"),
        Instrument("GOLD (XAU/USD)", "XAUUSD", "METALS", "Not connected"),
        Instrument("SILVER (XAG/USD)", "XAGUSD", "METALS", "Not connected")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 20, 35)
        window.navigationBarColor = Color.rgb(12, 20, 35)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 18)
            setBackgroundColor(Color.rgb(12, 20, 35))
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE) =
            TextView(this).apply { this.text = text; textSize = size; setTextColor(color) }

        root.addView(label("SMC ICT SIGNAL PRO", 24f))
        root.addView(label("Market selector • Crypto live data where supported", 13f, Color.LTGRAY))
        root.addView(label("Select market", 14f))
        market = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                instruments.map { "${it.category} • ${it.label}" })
        }
        root.addView(market, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 52))
        root.addView(label("Timeframe", 14f))
        timeframe = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("1m", "5m", "15m", "1h", "4h", "1d"))
            setSelection(2)
        }
        root.addView(timeframe)
        root.addView(Button(this).apply {
            text = "GET SIGNAL"
            setOnClickListener { loadSignal() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 54))
        status = label("Ready. Internet connection required.", 13f, Color.LTGRAY)
        root.addView(status)
        val scroll = ScrollView(this)
        resultBox = label("Select a market and tap GET SIGNAL.", 17f)
        resultBox.setPadding(16, 16, 16, 16)
        resultBox.setBackgroundColor(Color.rgb(23, 35, 52))
        scroll.addView(resultBox)
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        p.topMargin = 12
        root.addView(scroll, p)
        root.addView(label("Live candles currently connected only for supported Binance crypto pairs. India stocks, forex and metals are listed but require a licensed/compatible data provider. Signals are educational and not financial advice.", 11f, Color.LTGRAY))
        setContentView(root)
    }

    private fun loadSignal() {
        val selected = instruments[market.selectedItemPosition]
        if (selected.provider != "Binance") {
            status.text = "Market listed; live feed not connected."
            resultBox.setTextColor(Color.WHITE)
            resultBox.text = "${selected.label}\\nCategory: ${selected.category}\\n\\nLIVE DATA NOT CONNECTED\\n\\nThis market appears in the selector, but this build does not yet have a data provider for it. No BUY/SELL signal is generated without real market data."
            return
        }
        val interval = timeframe.selectedItem.toString()
        status.text = "Loading live candles for ${selected.symbol}..."
        resultBox.text = "Fetching market data…"
        thread {
            try {
                val endpoint = "https://api.binance.com/api/v3/klines?symbol=${selected.symbol}&interval=$interval&limit=100"
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"; connectTimeout = 10000; readTimeout = 10000
                    setRequestProperty("User-Agent", "SMC-ICT-Signal-Pro/1.1")
                }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                conn.disconnect()
                if (code !in 200..299) throw Exception("Market API error: $body")
                val candles = JSONArray(body)
                if (candles.length() < 30) throw Exception("Not enough candles returned.")
                val closes = mutableListOf<Double>()
                val highs = mutableListOf<Double>()
                val lows = mutableListOf<Double>()
                for (i in 0 until candles.length()) {
                    val c = candles.getJSONArray(i)
                    highs.add(c.getString(2).toDouble())
                    lows.add(c.getString(3).toDouble())
                    closes.add(c.getString(4).toDouble())
                }
                val last = closes.last()
                val e9 = ema(closes, 9); val e21 = ema(closes, 21)
                val prev9 = ema(closes.dropLast(1), 9); val prev21 = ema(closes.dropLast(1), 21)
                val swingHigh = highs.takeLast(20).maxOrNull()!!
                val swingLow = lows.takeLast(20).minOrNull()!!
                val crossedUp = prev9 <= prev21 && e9 > e21
                val crossedDown = prev9 >= prev21 && e9 < e21
                val signal = when {
                    crossedUp && last > closes[closes.size - 2] -> "BUY SETUP"
                    crossedDown && last < closes[closes.size - 2] -> "SELL SETUP"
                    e9 > e21 && last > e9 -> "BULLISH BIAS — WAIT FOR CONFIRMATION"
                    e9 < e21 && last < e9 -> "BEARISH BIAS — WAIT FOR CONFIRMATION"
                    else -> "NO CLEAR SIGNAL"
                }
                val report = listOf(
                    "SYMBOL: ${selected.label}", "TIMEFRAME: $interval", "LAST PRICE: ${df.format(last)}", "",
                    "SIGNAL: $signal", "", "EMA 9: ${df.format(e9)}", "EMA 21: ${df.format(e21)}", "",
                    "20-candle swing high: ${df.format(swingHigh)}",
                    "20-candle swing low: ${df.format(swingLow)}", "",
                    "Method: EMA trend + recent swing range.",
                    "This is a basic SMC/ICT-inspired prototype, not a full order-block/liquidity model."
                ).joinToString("\\n")
                val signalColor = when {
                    signal.startsWith("BUY") -> Color.rgb(82, 220, 145)
                    signal.startsWith("SELL") -> Color.rgb(255, 105, 105)
                    else -> Color.rgb(255, 210, 90)
                }
                runOnUiThread {
                    status.text = "Updated from live Binance data."
                    resultBox.text = report; resultBox.setTextColor(signalColor)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Could not fetch data."
                    resultBox.text = "Error: ${e.message ?: "Unknown error"}\\n\\nCheck internet and symbol. Binance availability can vary by region."
                    resultBox.setTextColor(Color.WHITE)
                }
            }
        }
    }

    private fun ema(values: List<Double>, period: Int): Double {
        val k = 2.0 / (period + 1.0)
        var value = values.take(period).average()
        for (i in period until values.size) value = values[i] * k + values[i] * (1.0 - k)
        return value
    }
}
